import React from "react";


export const EnterStakeWidget:React.FC =() =>{
    return (<div></div>);
}