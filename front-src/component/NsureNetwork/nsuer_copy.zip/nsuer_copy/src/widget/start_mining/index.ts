export {StakeCenterWidget} from './stake_to_mine/stake_centen'

