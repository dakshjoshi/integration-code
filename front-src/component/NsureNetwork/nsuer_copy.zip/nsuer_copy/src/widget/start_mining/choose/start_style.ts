import {css} from "styled-components";

export class StartStyle {
    static ButtonStyle = css`
width: 100%;

`
}
