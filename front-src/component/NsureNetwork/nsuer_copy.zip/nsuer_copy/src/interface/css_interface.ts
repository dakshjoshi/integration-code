export interface PaddingSize{
    x?:number,y?:number,all?:number
}
